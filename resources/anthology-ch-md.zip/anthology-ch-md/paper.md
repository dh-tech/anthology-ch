---
title: "Here is a Sample Paper Title"
authors:
  - name: Author One
    affiliation: 
      - "Some Department, Some University, Some City, Some Country"
      - "Another Department, Another University, Another City, Another Country"
    orcid: 0000-0000-0000-0000
    email: author@university.com
  - name: Author Two
    affiliation: "Some Department, Some University, Some City, Some Country"
    orcid: 0000-0000-0000-0001
  - name: Author Three
    affiliation: "Another Department, Another University, Another City, Another Country"
    orcid: ""
keywords: [computers, humanities proceedings]
abstract: |
  This Markdown template helps you typeset and format a paper for the Computational Humanities Research conference in the ACH Anthology. This template helps you adhere to the required specifications and provides an example of how your paper should look. In practice, the abstract of the paper here should be a one-paragraph summary of the outline and main contributions of the paper.
bibliography: bibliography.bib
---

# Introduction

Here is an example of the first section of the paper. You may modify this markdown file by renaming, deleting, or adding sections of your own and substituting our instructional text with the text of your paper. Add references to previous work to `bibliography.bib` as BibTeX entries. Refer to the Conference Call for Papers (CfP) for details about submission types and paper lengths.

## Details {#sec:intro_details}

You may also include subsections if they help organize your text, but they are not required. Use as many sections and subsections with whatever names work for your submission!

**Another tip.** In some cases, it may be helpful to use bold text to title individual paragraphs. For example, if a section describes features for a classifier, you can optionally title each paragraph with the name of each feature.

# Elements

## Citing elements

Here are some examples of how to construct and reference common elements in Markdown. References to elements such as tables, figures, equations and sections make use of label names that you set. References to citations should use the labels you indicate in `bibliography.bib`. Change all of these examples and values with your own data.

We can cite [Table @tbl:example] as well as [Figure @fig:example], and we also cite an example paper [@tettoni2024discoverability]. We can also include mathematical notations, such as:

$$f(y) = x^2$$ {#eq:squared}

The line number of the equation can be cited as [Equation @eq:squared]. You can also cite multiple papers together [@barré2024latent; @levenson2024textual; @bambaci2024steps], and reference figures or tables indirectly in parentheses ([Figure @fig:example_bigger]). You can also cite other sections or subsections of your paper, such as [Section @sec:intro_details].

| Column Name 1 | Column Name 2 |
|---------------|---------------|
| d1            | d2            |
| d1            | d2            |
| d1            | d2            |

Table: Example table and table caption. {#tbl:example}

## Required specifications

Tables and figures should *not* appear at the top of the first page above the paper title and abstract, but can be placed within the main text, as exemplified by [Table @tbl:example]. They may also be placed at the top of non-first pages, as exemplified by Figures [@fig:example] and [@fig:example_bigger]. Figures and tables discussed in the main text should appear *before* the References section. Supplementary materials should be referenced by their relevant Appendix section, such as [Appendix @sec:first-appendix].

Do *not* change the font size of table and figure captions, or the spacing between text lines, section/subsection titles, tables, figures, and captions. You should size your figures and tables so that they stay within the page width of the paper.

![Example figure and figure caption.](640x480.png){#fig:example width=40%}

![Example figure, where two images are placed side by side.](640x480.png){#fig:example_bigger width=40%}

# Acknowledgements {.unnumbered}

This unnumbered section should be blank when submitting your paper. After review, you may include lists of people and organizations who supported the work.

# References

<!-- Bibliography will be automatically generated here from the bibliography file -->

# Appendix A: First Appendix Section {#sec:first-appendix}

Appendix sections should be ordered by letters rather than numbers, and their contents do not count towards the paper's length limit. Appendix sections may also contain additional tables and figures.
